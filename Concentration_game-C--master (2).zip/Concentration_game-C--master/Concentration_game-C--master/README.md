# Concentration_game-C#
Game:
Pairs?
2 player or 1 player vs cpu
Timer for each turn
Different levels of difficulty, i.e harder = more cards & less time
3 forms? Start/Options, Game & Highscores
Option for displaying how to play




Classes
Menu form
Game form
Score form
Player?
Username
Score / scores?






GUI
Array of buttons
Timer
Some labels
Panels?
Buttons
Tab thing
