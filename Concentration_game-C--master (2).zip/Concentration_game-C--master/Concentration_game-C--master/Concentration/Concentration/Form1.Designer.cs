﻿namespace Concentration
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.HighScores = new System.Windows.Forms.Button();
            this.Players2 = new System.Windows.Forms.Button();
            this.PlayGame = new System.Windows.Forms.Button();
            this.Rules = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.LConcentration = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // HighScores
            // 
            this.HighScores.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HighScores.Location = new System.Drawing.Point(135, 343);
            this.HighScores.Name = "HighScores";
            this.HighScores.Size = new System.Drawing.Size(251, 56);
            this.HighScores.TabIndex = 0;
            this.HighScores.Text = "HighScores";
            this.HighScores.UseVisualStyleBackColor = true;
            // 
            // Players2
            // 
            this.Players2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Players2.Location = new System.Drawing.Point(135, 261);
            this.Players2.Name = "Players2";
            this.Players2.Size = new System.Drawing.Size(251, 56);
            this.Players2.TabIndex = 1;
            this.Players2.Text = "1 VS 1 ";
            this.Players2.UseVisualStyleBackColor = true;
            // 
            // PlayGame
            // 
            this.PlayGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayGame.Location = new System.Drawing.Point(135, 181);
            this.PlayGame.Name = "PlayGame";
            this.PlayGame.Size = new System.Drawing.Size(251, 56);
            this.PlayGame.TabIndex = 2;
            this.PlayGame.Text = "Play ";
            this.PlayGame.UseVisualStyleBackColor = true;
            // 
            // Rules
            // 
            this.Rules.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rules.Location = new System.Drawing.Point(135, 432);
            this.Rules.Name = "Rules";
            this.Rules.Size = new System.Drawing.Size(251, 56);
            this.Rules.TabIndex = 3;
            this.Rules.Text = "Rules";
            this.Rules.UseVisualStyleBackColor = true;
            this.Rules.Click += new System.EventHandler(this.Rules_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Firebrick;
            this.Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(343, 516);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(138, 66);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // LConcentration
            // 
            this.LConcentration.AutoSize = true;
            this.LConcentration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.LConcentration.Font = new System.Drawing.Font("Segoe Script", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LConcentration.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.LConcentration.Location = new System.Drawing.Point(114, 63);
            this.LConcentration.Name = "LConcentration";
            this.LConcentration.Size = new System.Drawing.Size(314, 63);
            this.LConcentration.TabIndex = 5;
            this.LConcentration.Text = "Consentration";
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(511, 608);
            this.Controls.Add(this.LConcentration);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Rules);
            this.Controls.Add(this.PlayGame);
            this.Controls.Add(this.Players2);
            this.Controls.Add(this.HighScores);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MenuForm";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.MenuForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button HighScores;
        private System.Windows.Forms.Button Players2;
        private System.Windows.Forms.Button PlayGame;
        private System.Windows.Forms.Button Rules;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label LConcentration;
    }
}

